# Exercise 1 — reference solution notes

Changed files: `ApprovalService.java`, `ExpenseReport.java`, `EmployeeDirectory.java`.
Copy them over the starter files and add the follow-up tests to run everything.

## How the solution thinks

- **The org chart is a tree; escalation is a walk up it.** One private method,
  `nextAvailableApprover`, does the walk, and both `submit` and `approve` reuse it. That's why
  follow-up 1 (skip people on leave) was a three-line change instead of two copies.
- **History is a `List<String>` inside the report**, exposed as `List.copyOf(...)` so callers
  can't change it.
- **Work out the next step before mutating.** `approve` finds the next approver first, so if the
  walk throws (cycle), the report is left as it was.
- **Cycle safety uses a `HashSet` of visited ids** (O(depth)). The "already approved" check uses
  the history list. The history is short, so `contains` on a list is fine. Say that out loud.
- **Queue order is a composed `Comparator`**: `comparing(amount <= HIGH_VALUE)` puts `false`
  (the big reports) first, then `thenComparing(submittedAt)`. The threshold is a named constant.

## What to say in the interview

- "Before I add escalation, I'll check the existing `approve` tests still describe what we want."
- "I'm treating a manager missing from the directory like 'no manager'. Is that right, or should it
  error?"
- "Sorting on every `pendingFor` call is O(n log n) over all reports. Fine at this size. At scale
  I'd index pending reports by approver (`Map<String, PriorityQueue<ExpenseReport>>`) or let the
  database sort."
- "For reports already waiting on someone who goes on leave, I'd add a re-route job rather than
  changing it implicitly. That's a product decision to confirm."

## Common mistakes

- Setting `APPROVED` before checking the limit, or comparing with `<` instead of `<=` (the
  "exactly at the limit" test catches this).
- Recording the approval twice when the report escalates.
- Making `approvalHistory()` return the internal mutable list.
- Forgetting the existing `employeeWithNoManagerCannotSubmit` test when adding the "everyone on
  leave → finance" path.

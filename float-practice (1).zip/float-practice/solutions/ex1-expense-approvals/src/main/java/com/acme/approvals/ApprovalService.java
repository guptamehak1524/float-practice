package com.acme.approvals;

import java.time.Clock;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Reference solution after TASK + FOLLOWUP-1 + FOLLOWUP-2.
 * Reports climb the org chart until someone with a high enough limit approves.
 */
public class ApprovalService {

    /** Reports strictly above this amount jump the queue (FOLLOWUP-2). */
    static final long HIGH_VALUE_CENTS = 500_000;

    private static final Comparator<ExpenseReport> QUEUE_ORDER =
            Comparator.comparing((ExpenseReport r) -> r.amountCents() <= HIGH_VALUE_CENTS)   // false (big) first
                      .thenComparing(ExpenseReport::submittedAt);

    private final EmployeeDirectory directory;
    private final ReportRepository repository;
    private final Clock clock;
    private int nextId = 1;

    public ApprovalService(EmployeeDirectory directory, ReportRepository repository, Clock clock) {
        this.directory = directory;
        this.repository = repository;
        this.clock = clock;
    }

    public ExpenseReport submit(String employeeId, long amountCents, String description) {
        if (amountCents <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
        Employee employee = directory.find(employeeId)
                .orElseThrow(() -> new IllegalArgumentException("Unknown employee " + employeeId));
        if (directory.managerOf(employee.id()).isEmpty()) {
            throw new IllegalStateException(employeeId + " has no manager to approve this");
        }

        ExpenseReport report = new ExpenseReport("R-" + nextId++, employeeId, amountCents, description, clock.instant());
        routeAbove(employee.id(), report);
        repository.save(report);
        return report;
    }

    public ExpenseReport approve(String reportId, String approverId) {
        ExpenseReport report = loadPendingReportFor(reportId, approverId);
        Employee approver = directory.find(approverId)
                .orElseThrow(() -> new IllegalStateException("Approver " + approverId + " is not in the directory"));

        if (report.amountCents() <= approver.approvalLimitCents()) {
            report.recordApproval(approverId);
            report.setStatus(ReportStatus.APPROVED);
            report.setCurrentApproverId(null);
            return report;
        }

        // Find the next approver BEFORE changing anything, so a failure leaves the report untouched.
        Optional<Employee> next = nextAvailableApprover(approverId, report.approvalHistory(), approverId);
        report.recordApproval(approverId);
        if (next.isPresent()) {
            report.setCurrentApproverId(next.get().id());
        } else {
            report.setStatus(ReportStatus.ESCALATED_TO_FINANCE);
            report.setCurrentApproverId(null);
        }
        return report;
    }

    public ExpenseReport reject(String reportId, String approverId, String reason) {
        ExpenseReport report = loadPendingReportFor(reportId, approverId);
        report.setStatus(ReportStatus.REJECTED);
        report.setRejectionReason(reason);
        report.setCurrentApproverId(null);
        return report;
    }

    /** Reports waiting on this approver: big ones first, then oldest first. */
    public List<ExpenseReport> pendingFor(String approverId) {
        return repository.findAll().stream()
                .filter(r -> r.status() == ReportStatus.PENDING)
                .filter(r -> approverId.equals(r.currentApproverId()))
                .sorted(QUEUE_ORDER)
                .toList();
    }

    private void routeAbove(String employeeId, ExpenseReport report) {
        Optional<Employee> next = nextAvailableApprover(employeeId, report.approvalHistory(), null);
        if (next.isPresent()) {
            report.setCurrentApproverId(next.get().id());
        } else {
            report.setStatus(ReportStatus.ESCALATED_TO_FINANCE);
            report.setCurrentApproverId(null);
        }
    }

    /**
     * Walks up from {@code fromEmployeeId} to the first manager who is not on leave.
     * Throws if the walk loops, or would hand the report back to someone who already approved it.
     */
    private Optional<Employee> nextAvailableApprover(String fromEmployeeId, List<String> alreadyApproved, String actingApprover) {
        Set<String> visited = new HashSet<>();
        visited.add(fromEmployeeId);
        Optional<Employee> candidate = directory.managerOf(fromEmployeeId);
        while (candidate.isPresent()) {
            Employee manager = candidate.get();
            if (!visited.add(manager.id())) {
                throw new IllegalStateException("Org chart cycle detected at " + manager.id());
            }
            if (alreadyApproved.contains(manager.id()) || manager.id().equals(actingApprover)) {
                throw new IllegalStateException("Approval cycle: " + manager.id() + " already approved this report");
            }
            if (!directory.isOnLeave(manager.id())) {
                return Optional.of(manager);
            }
            candidate = directory.managerOf(manager.id());
        }
        return Optional.empty();
    }

    private ExpenseReport loadPendingReportFor(String reportId, String approverId) {
        ExpenseReport report = repository.findById(reportId)
                .orElseThrow(() -> new IllegalArgumentException("Unknown report " + reportId));
        if (report.status() != ReportStatus.PENDING) {
            throw new IllegalStateException("Report " + reportId + " is already " + report.status());
        }
        if (!approverId.equals(report.currentApproverId())) {
            throw new NotAuthorizedException(approverId + " cannot act on report " + reportId);
        }
        return report;
    }
}

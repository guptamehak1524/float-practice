# Exercise 3 — reference solution notes

Changed files: `TransferService.java`, `Ledger.java`. New: `Statement.java`, `StatementLine.java`.

## How the solution thinks

- **Idempotency = `Map<key, (request, result)>`.** Storing the original request (a private
  record) is what lets you detect "same key, different request". Only successful transfers are
  stored, so a failed attempt can be retried.
- **One private `execute` method** does validate-then-post for normal transfers, keyed transfers
  and reversals. The currency fix lands in one place and covers all three.
- **Reversals append, never edit.** A reversal is just another transfer in the opposite direction.
  Two `Set`s track "already reversed" and "is a reversal". Mark as reversed only **after** the
  reversal succeeds, so an insufficient-funds failure doesn't block a later retry.
- **O(1) balance:** keep `Map<accountId, Long>` updated inside `post`, the only write path, so the
  balance and the entries can't drift apart.
- **Per-account entry lists** make `entries` and `statement` O(entries for that account), not O(all entries).
- **Statement is a running sum (prefix sum)** over that account's entries: everything before `from`
  becomes the opening balance, and lines carry the running balance. Dates are converted with
  `atZone(America/Toronto)`, which also handles the DST change on Nov 1 2026.

## What to say in the interview

- "In a real system the idempotency map would be a database table with a unique constraint on the
  key, written in the same transaction as the ledger entries. Otherwise a crash between the two
  breaks the guarantee."
- "Money should never be created or destroyed. I'd add a test that the sum of all balances equals
  the sum of external deposits."
- "For huge accounts I'd store daily totals in a `TreeMap<LocalDate, Long>` and use `headMap` for
  the opening balance, or let the database do it with an index on (account, date)."

## Common mistakes

- Saving the idempotency key **before** the transfer succeeds, so a failed transfer blocks retries.
- Returning a *new* `Transfer` on retry instead of the original one (the test uses `assertEquals`).
- Using UTC dates for the statement (the 22:00 Toronto entry would land on the wrong day).
- Forgetting to update the cached balance somewhere other than `post`.

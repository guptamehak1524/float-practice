package com.acme.ledger;

import java.time.LocalDate;

public record StatementLine(LocalDate date, String description, long amountCents, long balanceAfterCents) {
}

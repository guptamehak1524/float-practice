package com.acme.ledger;

import java.util.List;

public record Statement(long openingBalanceCents, List<StatementLine> lines, long closingBalanceCents) {
}

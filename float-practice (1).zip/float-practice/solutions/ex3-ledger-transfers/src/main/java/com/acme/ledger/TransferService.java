package com.acme.ledger;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/** Reference solution after TASK + FOLLOWUP-1 (FOLLOWUP-2 lives in Ledger). */
public class TransferService {

    /** What a client asked for. Used to spot a key being reused for a different request. */
    private record TransferRequest(String fromId, String toId, long amountCents, String memo) {}

    private record IdempotentResult(TransferRequest request, Transfer transfer) {}

    private final Ledger ledger;
    private final Map<String, Transfer> transfers = new HashMap<>();
    private final Map<String, IdempotentResult> byIdempotencyKey = new HashMap<>();
    private final Set<String> reversedTransferIds = new HashSet<>();
    private final Set<String> reversalIds = new HashSet<>();
    private int nextTransferId = 1;

    public TransferService(Ledger ledger) {
        this.ledger = ledger;
    }

    public Transfer transfer(String fromId, String toId, long amountCents, String memo) {
        return execute(fromId, toId, amountCents, memo);
    }

    public Transfer transfer(String idempotencyKey, String fromId, String toId, long amountCents, String memo) {
        if (idempotencyKey == null || idempotencyKey.isBlank()) {
            throw new IllegalArgumentException("Idempotency key is required");
        }
        TransferRequest request = new TransferRequest(fromId, toId, amountCents, memo);
        IdempotentResult previous = byIdempotencyKey.get(idempotencyKey);
        if (previous != null) {
            if (!previous.request().equals(request)) {
                throw new IllegalStateException("Idempotency key " + idempotencyKey + " was used for a different transfer");
            }
            return previous.transfer();
        }
        Transfer t = execute(fromId, toId, amountCents, memo);       // throws => key is not stored
        byIdempotencyKey.put(idempotencyKey, new IdempotentResult(request, t));
        return t;
    }

    public Transfer reverse(String transferId, String reason) {
        Transfer original = transfers.get(transferId);
        if (original == null) {
            throw new IllegalArgumentException("Unknown transfer " + transferId);
        }
        if (reversalIds.contains(transferId)) {
            throw new IllegalStateException(transferId + " is itself a reversal");
        }
        if (reversedTransferIds.contains(transferId)) {
            throw new IllegalStateException(transferId + " was already reversed");
        }
        Transfer reversal = execute(original.toAccountId(), original.fromAccountId(), original.amountCents(),
                "Reversal of " + transferId + ": " + reason);
        reversedTransferIds.add(transferId);                          // only after it succeeded
        reversalIds.add(reversal.id());
        return reversal;
    }

    public Optional<Transfer> find(String transferId) {
        return Optional.ofNullable(transfers.get(transferId));
    }

    /** Validates everything first, then posts. Nothing is written if any check fails. */
    private Transfer execute(String fromId, String toId, long amountCents, String memo) {
        if (amountCents <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
        if (fromId.equals(toId)) {
            throw new IllegalArgumentException("Cannot transfer to the same account");
        }
        Account from = ledger.account(fromId).orElseThrow(() -> new IllegalArgumentException("Unknown account " + fromId));
        Account to = ledger.account(toId).orElseThrow(() -> new IllegalArgumentException("Unknown account " + toId));
        if (!from.currency().equals(to.currency())) {
            throw new IllegalArgumentException("Currency mismatch: " + from.currency() + " -> " + to.currency());
        }
        long available = ledger.balance(fromId);
        if (available < amountCents) {
            throw new InsufficientFundsException(fromId, available, amountCents);
        }

        String id = "T-" + nextTransferId++;
        ledger.post(fromId, -amountCents, "Transfer " + id + " to " + toId + ": " + memo);
        ledger.post(toId, amountCents, "Transfer " + id + " from " + fromId + ": " + memo);
        Transfer t = new Transfer(id, fromId, toId, amountCents, memo, ledger.clock().instant());
        transfers.put(id, t);
        return t;
    }
}

package com.acme.ledger;

import java.time.Clock;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Append-only ledger. Reference solution for FOLLOWUP-2: O(1) balances and statements. */
public class Ledger {

    static final ZoneId BOOKS_ZONE = ZoneId.of("America/Toronto");

    private final Map<String, Account> accounts = new HashMap<>();
    private final Map<String, List<LedgerEntry>> entriesByAccount = new HashMap<>();
    private final Map<String, Long> balances = new HashMap<>();
    private final Clock clock;
    private int nextEntryId = 1;

    public Ledger(Clock clock) {
        this.clock = clock;
    }

    public void openAccount(Account account) {
        if (accounts.containsKey(account.id())) {
            throw new IllegalArgumentException("Account already exists: " + account.id());
        }
        accounts.put(account.id(), account);
        entriesByAccount.put(account.id(), new ArrayList<>());
        balances.put(account.id(), 0L);
    }

    public Optional<Account> account(String accountId) {
        return Optional.ofNullable(accounts.get(accountId));
    }

    /** The only write path, so the running balance and the entries can't drift apart. */
    public LedgerEntry post(String accountId, long amountCents, String description) {
        if (!accounts.containsKey(accountId)) {
            throw new IllegalArgumentException("Unknown account " + accountId);
        }
        LedgerEntry entry = new LedgerEntry("E-" + nextEntryId++, accountId, amountCents, description, clock.instant());
        entriesByAccount.get(accountId).add(entry);
        balances.merge(accountId, amountCents, Long::sum);
        return entry;
    }

    /** O(1): maintained on every post. */
    public long balance(String accountId) {
        return balances.getOrDefault(accountId, 0L);
    }

    /** All entries for an account, oldest first (read-only view). */
    public List<LedgerEntry> entries(String accountId) {
        return Collections.unmodifiableList(entriesByAccount.getOrDefault(accountId, List.of()));
    }

    public Statement statement(String accountId, LocalDate fromInclusive, LocalDate toInclusive) {
        if (fromInclusive.isAfter(toInclusive)) {
            throw new IllegalArgumentException("from must be on or before to");
        }
        long running = 0;
        long opening = 0;
        List<StatementLine> lines = new ArrayList<>();
        for (LedgerEntry e : entries(accountId)) {                 // entries are in time order
            LocalDate date = e.at().atZone(BOOKS_ZONE).toLocalDate();
            if (date.isAfter(toInclusive)) {
                break;
            }
            running += e.amountCents();
            if (date.isBefore(fromInclusive)) {
                opening = running;
            } else {
                lines.add(new StatementLine(date, e.description(), e.amountCents(), running));
            }
        }
        long closing = lines.isEmpty() ? opening : lines.get(lines.size() - 1).balanceAfterCents();
        return new Statement(opening, List.copyOf(lines), closing);
    }

    Clock clock() {
        return clock;
    }
}

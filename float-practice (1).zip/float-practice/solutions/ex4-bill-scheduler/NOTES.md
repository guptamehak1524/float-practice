# Exercise 4 — reference solution notes

Changed files: `PaymentRunner.java`, `BillScheduler.java`, `BusinessCalendar.java`.

## How the solution thinks

- **Turn the ticket into one rule:** "pay every unpaid bill whose *pay date* is today or earlier",
  where pay date = due date moved back to the closest business day. That single rule fixes weekends,
  holidays **and** the missed-run catch-up. The old code compared dates with `equals`; the fix is `<=`.
- **`BusinessCalendar.onOrBefore`** loops backwards day by day. It's simple and correct even for a
  holiday next to a weekend (Christmas Friday + Saturday → Thursday).
- **Deterministic order** via one composed `Comparator` (due date, amount desc, id). Without the id
  tie-breaker, tests that compare lists could fail at random.
- **Bills keyed by id in a `LinkedHashMap`**: O(1) duplicate check and removal, and insertion order kept.
  The starter's linear scan for duplicates was O(n).
- **Monthly series store the intended `dayOfMonth`**, not the last due date, and clamp per month with
  `Math.min(day, month.lengthOfMonth())`. That's what stops Jan 31 → Feb 28 → Mar 28 drift.
- **Budget = greedy pass with `continue`.** `run(today)` delegates to `run(today, Long.MAX_VALUE)`,
  so there's one code path.

## What to say in the interview

- "I'll ask product whether weekend bills should be paid early (Friday) or late (Monday). Paying
  early avoids late fees, so I'll assume that unless told otherwise."
- "Filtering and sorting all unpaid bills each run is O(n log n). For millions of bills I'd keep a
  `PriorityQueue` or an index by pay date, or query the database for `pay_date <= today`."
- "If the gateway throws halfway through, some bills are paid and others aren't. In production each
  payment needs an idempotency key with the bank, plus a status per bill (PENDING → SENT → CONFIRMED)."

## Common mistakes

- Looking only at *next* weekend days and forgetting overdue bills from earlier days.
- Moving weekend bills **forward** to Monday (that makes them late).
- Breaking out of the budget loop at the first bill that doesn't fit, instead of skipping it.
- Computing next month's due date from the previous *clamped* date (the drift bug).

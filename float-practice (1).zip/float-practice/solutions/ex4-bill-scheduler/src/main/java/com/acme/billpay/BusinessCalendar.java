package com.acme.billpay;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Set;

/** Bank business days: Monday to Friday, excluding bank holidays. */
public class BusinessCalendar {

    private final Set<LocalDate> holidays;

    public BusinessCalendar(Set<LocalDate> holidays) {
        this.holidays = Set.copyOf(holidays);
    }

    public boolean isBusinessDay(LocalDate date) {
        DayOfWeek d = date.getDayOfWeek();
        return d != DayOfWeek.SATURDAY && d != DayOfWeek.SUNDAY && !holidays.contains(date);
    }

    /** The date itself if it's a business day, otherwise the closest business day before it. */
    public LocalDate onOrBefore(LocalDate date) {
        LocalDate d = date;
        while (!isBusinessDay(d)) {
            d = d.minusDays(1);
        }
        return d;
    }
}

package com.acme.billpay;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Holds bills waiting to be paid. Reference solution including monthly series (FOLLOWUP-1). */
public class BillScheduler {

    /** What we need to generate the next bill in a monthly series. */
    private record Series(String seriesId, String vendor, long amountCents, int dayOfMonth) {}

    private final Map<String, Bill> bills = new LinkedHashMap<>();        // id -> bill, keeps order, O(1) lookup
    private final Map<String, Series> seriesByBillId = new HashMap<>();

    public void schedule(Bill bill) {
        if (bills.containsKey(bill.id())) {
            throw new IllegalArgumentException("Bill already scheduled: " + bill.id());
        }
        bills.put(bill.id(), bill);
    }

    public void scheduleMonthly(String seriesId, String vendor, long amountCents, int dayOfMonth, YearMonth firstMonth) {
        if (dayOfMonth < 1 || dayOfMonth > 31) {
            throw new IllegalArgumentException("dayOfMonth must be 1-31");
        }
        scheduleInstance(new Series(seriesId, vendor, amountCents, dayOfMonth), firstMonth);
    }

    /** Bills due on exactly this date, largest first. (Kept for existing callers.) */
    public List<Bill> billsDueOn(LocalDate date) {
        return bills.values().stream()
                .filter(b -> b.dueDate().equals(date))
                .sorted(Comparator.comparingLong(Bill::amountCents).reversed())
                .toList();
    }

    /** Removes the bill; if it belongs to a monthly series, schedules next month's bill. */
    public void markPaid(String billId) {
        Bill paid = bills.remove(billId);
        Series series = seriesByBillId.remove(billId);
        if (paid != null && series != null) {
            scheduleInstance(series, YearMonth.from(paid.dueDate()).plusMonths(1));
        }
    }

    public List<Bill> unpaidBills() {
        return List.copyOf(bills.values());
    }

    private void scheduleInstance(Series s, YearMonth month) {
        int day = Math.min(s.dayOfMonth(), month.lengthOfMonth());      // clamp, but remember the intended day
        Bill bill = new Bill(s.seriesId() + "-" + month, s.vendor(), s.amountCents(), month.atDay(day));
        schedule(bill);
        seriesByBillId.put(bill.id(), s);
    }
}

package com.acme.billpay;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** The daily payment job. Reference solution after TASK + both follow-ups. */
public class PaymentRunner {

    static final Comparator<Bill> PAY_ORDER = Comparator.comparing(Bill::dueDate)
            .thenComparing(Comparator.comparingLong(Bill::amountCents).reversed())
            .thenComparing(Bill::id);

    private final BillScheduler scheduler;
    private final PaymentGateway gateway;
    private final BusinessCalendar calendar;

    public PaymentRunner(BillScheduler scheduler, PaymentGateway gateway, BusinessCalendar calendar) {
        this.scheduler = scheduler;
        this.gateway = gateway;
        this.calendar = calendar;
    }

    public List<Payment> run(LocalDate today) {
        return run(today, Long.MAX_VALUE);
    }

    public List<Payment> run(LocalDate today, long budgetCents) {
        if (!calendar.isBusinessDay(today)) {
            throw new IllegalArgumentException(today + " is not a business day");
        }
        if (budgetCents < 0) {
            throw new IllegalArgumentException("budget must be >= 0");
        }

        // One rule: pay every bill whose pay date (due date, moved back to a business day) is today or earlier.
        List<Bill> payable = scheduler.unpaidBills().stream()
                .filter(b -> !calendar.onOrBefore(b.dueDate()).isAfter(today))
                .sorted(PAY_ORDER)
                .toList();

        long remaining = budgetCents;
        List<Payment> payments = new ArrayList<>();
        for (Bill bill : payable) {
            if (bill.amountCents() > remaining) {
                continue;                                    // skip, a smaller bill may still fit
            }
            String confirmation = gateway.pay(bill.vendor(), bill.amountCents());
            scheduler.markPaid(bill.id());
            remaining -= bill.amountCents();
            payments.add(new Payment(bill.id(), bill.vendor(), bill.amountCents(), confirmation, today));
        }
        return payments;
    }
}

package com.acme.cards;

import java.time.YearMonth;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

/**
 * Tracks spend per card per calendar month, overall and per merchant category.
 * Keying by month means there is no reset job: a new month simply starts at zero.
 */
public class SpendTracker {

    private record CardMonth(String cardId, YearMonth month) {}

    private final Map<CardMonth, Long> totalByCardMonth = new HashMap<>();
    private final Map<CardMonth, Map<MerchantCategory, Long>> categoryByCardMonth = new HashMap<>();
    private final Map<String, Long> lifetimeByCard = new HashMap<>();

    /** Lifetime spend. Kept for existing callers; limit checks use {@link #spent(String, YearMonth)}. */
    public long spent(String cardId) {
        return lifetimeByCard.getOrDefault(cardId, 0L);
    }

    public long spent(String cardId, YearMonth month) {
        return totalByCardMonth.getOrDefault(new CardMonth(cardId, month), 0L);
    }

    public long spent(String cardId, YearMonth month, MerchantCategory category) {
        Map<MerchantCategory, Long> byCategory = categoryByCardMonth.get(new CardMonth(cardId, month));
        return byCategory == null ? 0L : byCategory.getOrDefault(category, 0L);
    }

    /** Old signature, kept so existing code compiles. Records against no particular month. */
    public void record(String cardId, long amountCents) {
        lifetimeByCard.merge(cardId, amountCents, Long::sum);
    }

    public void record(String cardId, YearMonth month, MerchantCategory category, long amountCents) {
        CardMonth key = new CardMonth(cardId, month);
        totalByCardMonth.merge(key, amountCents, Long::sum);
        categoryByCardMonth.computeIfAbsent(key, k -> new EnumMap<>(MerchantCategory.class))
                           .merge(category, amountCents, Long::sum);
        lifetimeByCard.merge(cardId, amountCents, Long::sum);
    }
}

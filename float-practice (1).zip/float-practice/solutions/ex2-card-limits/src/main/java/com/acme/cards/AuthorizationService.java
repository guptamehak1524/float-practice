package com.acme.cards;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.YearMonth;
import java.time.ZoneId;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Reference solution after TASK + FOLLOWUP-1 + FOLLOWUP-2.
 * Order of checks: amount -> card exists -> card active -> velocity -> monthly limit -> category limit.
 */
public class AuthorizationService {

    static final ZoneId COMPANY_ZONE = ZoneId.of("America/Toronto");
    static final int MAX_ATTEMPTS_PER_WINDOW = 3;
    static final Duration VELOCITY_WINDOW = Duration.ofSeconds(60);

    private record CardMerchant(String cardId, String merchant) {}

    private final CardRepository cards;
    private final SpendTracker spendTracker;
    private final Clock clock;
    private final List<AuthorizationRecord> log = new ArrayList<>();
    private final Map<String, Map<MerchantCategory, Long>> categoryLimits = new HashMap<>();
    private final Map<CardMerchant, Deque<Instant>> recentApprovals = new HashMap<>();

    public AuthorizationService(CardRepository cards, SpendTracker spendTracker, Clock clock) {
        this.cards = cards;
        this.spendTracker = spendTracker;
        this.clock = clock;
    }

    public AuthorizationResult authorize(AuthorizationRequest request) {
        Instant now = clock.instant();
        AuthorizationResult result = decide(request, now);
        log.add(new AuthorizationRecord(now, request, result));
        return result;
    }

    public void setCategoryLimit(String cardId, MerchantCategory category, long limitCents) {
        if (limitCents < 0) {
            throw new IllegalArgumentException("limitCents must be >= 0");
        }
        if (cards.findById(cardId).isEmpty()) {
            throw new IllegalArgumentException("Unknown card " + cardId);
        }
        categoryLimits.computeIfAbsent(cardId, k -> new EnumMap<>(MerchantCategory.class)).put(category, limitCents);
    }

    public List<AuthorizationRecord> history(String cardId) {
        return log.stream().filter(r -> r.request().cardId().equals(cardId)).toList();
    }

    private AuthorizationResult decide(AuthorizationRequest request, Instant now) {
        if (request.amountCents() <= 0) {
            return AuthorizationResult.decline(DeclineReason.INVALID_AMOUNT);
        }
        Optional<Card> maybeCard = cards.findById(request.cardId());
        if (maybeCard.isEmpty()) {
            return AuthorizationResult.decline(DeclineReason.CARD_NOT_FOUND);
        }
        Card card = maybeCard.get();
        if (card.status() != CardStatus.ACTIVE) {
            return AuthorizationResult.decline(DeclineReason.CARD_NOT_ACTIVE);
        }

        Deque<Instant> recent = recentApprovals.computeIfAbsent(
                new CardMerchant(card.id(), request.merchant()), k -> new ArrayDeque<>());
        evictOlderThanWindow(recent, now);
        if (recent.size() >= MAX_ATTEMPTS_PER_WINDOW) {
            return AuthorizationResult.decline(DeclineReason.TOO_MANY_ATTEMPTS);
        }

        YearMonth month = YearMonth.from(now.atZone(COMPANY_ZONE));
        long amount = request.amountCents();
        if (spendTracker.spent(card.id(), month) + amount > card.monthlyLimitCents()) {
            return AuthorizationResult.decline(DeclineReason.MONTHLY_LIMIT_EXCEEDED);
        }
        Long categoryCap = categoryLimits.getOrDefault(card.id(), Map.of()).get(request.category());
        if (categoryCap != null
                && spendTracker.spent(card.id(), month, request.category()) + amount > categoryCap) {
            return AuthorizationResult.decline(DeclineReason.CATEGORY_LIMIT_EXCEEDED);
        }

        // Only now, once every check has passed, do we change any state.
        spendTracker.record(card.id(), month, request.category(), amount);
        recent.addLast(now);
        return AuthorizationResult.approve();
    }

    /** Drops timestamps at or before now - window. Each timestamp is removed at most once: O(1) amortised. */
    private static void evictOlderThanWindow(Deque<Instant> recent, Instant now) {
        Instant cutoff = now.minus(VELOCITY_WINDOW);
        while (!recent.isEmpty() && !recent.peekFirst().isAfter(cutoff)) {
            recent.pollFirst();
        }
    }
}
